const express = require('express');
const KBiz = require('./class/KBiz');

const app = express();
const PORT = 3000;

app.get('/', async (req, res) => {
  const { user, pass, banknum } = req.query;

  if (!user || !pass || !banknum) {
    return res.status(400).json({ error: 'Missing required parameters.' });
  }

  const config = {
    username: user,
    password: pass,
    bankAccountNumber: banknum,
  };

  const kBizClient = new KBiz(config);
  const loginData = await kBizClient.login();

  if (loginData.success) {
    const sessionIsAlive = await kBizClient.checkSession();

    if (sessionIsAlive) {
      const transactionList = await kBizClient.getTransactionList(100, '21/09/2024', '21/09/2024');
      return res.json(transactionList);
    } else {
      return res.status(401).json({ error: 'Session is dead.' });
    }
  } else {
    return res.status(401).json({ error: 'Login failed.' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
